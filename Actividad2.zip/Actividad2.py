#1. Hacer un programa que solicite por teclado dos número y muestre la suma, la resta,
#la multiplicación y la división de esos números
print("BIENVENIDO A MI PROGRAMA")
numero1 = int( input("numero 1:"))
numero2= int( input("numero 2:"))
suma = numero1 +numero2
print("_________________________SUMANDO_________________________")
print("total:",suma)
print("_________________________________________________________")

#2. Hacer un programa que solicite una edad y determine si es mayor de edad.
print("BIENVENIDO A MI PROGRAMA")
edad = int( input("ingrese su edad: "))
if edad >= 18:
    print("usted es mayor de edad")
else:
    print("usted es menor de edad")
print("_________________________________________________________")

#3. Hacer un programa que solicite una edad e imprima “Es mayor” si es mayor de
#edad, sino que imprima “Es menor”.
print("BIENVENIDO A MI PROGRAMA")
edad1 = int (input("ingrese una edad: "))
if edad1 >= 18:
    print("es mayor")
else: 
    print("es menor")
print("_________________________________________________________")

#4. Hacer un programa que solicite un color por teclado e imprima “Puede pasar “ si el
#color ingresado es verde, “Precaución “ si es amarillo, “No pasar “ si es rojo o “Color
#inválido” si es cualquier otro.
print("BIENVENIDO A MI PROGRAMA")
color = input(" ingrese un color: ")
if color == "verde": 
    print("puede pasar")
elif color == "amarillo": 
    print("precaución")
elif color == "rojo":
    print("no pasar")
else: 
    print("color desconocido")
print("_________________________________________________________")

#5. Hacer un programa que cuente desde el 1 al 100 y los imprima uno a uno
